<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- wrapper content -->
<div class="wrap-all-content">
	<div class="wrap-section-1">
		<div class="container">
			<!-- slider -->
			<div class="slider-header">
				<?php
				if($active_homeslider){
					foreach($active_homeslider AS $red){
						echo '<div class="item">
							<div class="item-slide-h">
								<img src="'.base_url('storage/homeslider/'.$red->cover).'" alt="'.$red->title.'">
								<div class="overlay-item-slide-table">
									<div class="overlay-item-slide">
										<div class="con-width-overlay-slide">
											<h2>'.$red->title.'</h2>
											'.($red->location ? '<h4><i class="fa fa-map-marker"></i> '.$red->location.'</h4>':'').'
											<p>
												'.clean_html($red->description).'
											</p>
											<div class="bt-readmore">
												<a href="'.prep_url($red->url).'">'.translation('readmore').'</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>';
					}
				}
				?>
			</div>
			<!-- box -->
			<div class="wrap-content-box-home">
				<div class="row">
					<?php
					if($featured_program){
						foreach($featured_program AS $red){
							echo '<div class="col-sm-4">
								<div class="item-box-content-home">
									<div class="i-box-c-home-img">
										<img src="'.base_url('storage/content/'.$red->cover).'" alt="'.$red->title.'">
									</div>
									<div class="i-box-c-home-info">
										<h3>'.$red->title.'</h3>
										<p>
										'.clean_html($red->teaser).'
										</p>
										<div class="bt-readmore2">
											<a href="'.base_lang('program/detail/'.$red->slug).'">'.translation('readmore').'</a>
										</div>
									</div>
								</div>
							</div>';
						}
					}
					?>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- section bottom info -->
<div class="wrap-sec-bottom-info">
	<div class="container">
		<div class="sec-logo-info">
			<?php
				if($partnership){
					foreach($partnership AS $no => $red){
						$no += 1;
						echo '<div class="item-logo-info'.$no.'">
							<a href="'.prep_url($red->url).'" target="_blank"><img src="'.base_url('storage/partnership/'.$red->cover).'" alt="'.$red->url.'"></a>
						</div>';
						
						if($no == 2){
							$no = 1;
						}
					}
				}
			?>
			<div class="clear"></div>
		</div>
		<div class="s-bottom-info-text">
			<h4><?php echo translation('contact_about');?></h4>
		</div>
		<div class="wrap-news-letter">
			<h2><?php echo translation('inbox_title_form');?></h2>
			
			<?php echo form_open('contact/add', 'class="news-letter"');?>
				<div class="row">
					<div class="col-lg-12">
						<input name="fullname" type="text" class="i-text-form-f" placeholder="<?php echo translation('contact_field_fullname');?>*" required>
						<input name="email" type="email" class="i-text-form-f" placeholder="Email*" required>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<h4 class="newsletter-req">
							* <?php echo translation('inbox_required_alert');?>
						</h4>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<textarea name="message" id="" class="i-textarea-form" placeholder="<?php echo translation('contact_field_message');?>*" required></textarea>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<input name="submit_form" type="submit" value="<?php echo translation('contact_field_submit');?>" class="s-input-form">
					</div>
				</div>
			<?php echo form_close();?>
			
		</div>
		<div class="social-net-icon">
			<h4><?php echo translation('sosmed_title_follow');?></h4>
			<ul>
				<li><a href="<?php echo ACCOUNT_FB;?>" target="_blank"><i class="fa fa-facebook-square"></i></a></li>
				<li><a href="<?php echo ACCOUNT_TW;?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
				<li><a href="<?php echo ACCOUNT_INS;?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
				<li><a href="<?php echo ACCOUNT_YTB;?>" target="_blank"><i class="fa fa-youtube"></i></a></li>
			</ul>
		</div>
	</div>
</div>