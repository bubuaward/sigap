<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

	<!-- footer -->
	<div class="wrap-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="wrap-f-subscribe">
						<h3><?php echo translation('footer_title_subscribe');?></h3>
						<div class="form-subscribe">
							
							<?php echo form_open('subscribe/add');?>
							<input name="email" type="email" class="f-sub-input" placeholder="email" required>
							<input type="submit" class="f-submit" value="<?php echo translation('subscribe');?>">
							<?php echo form_close();?>
							
							<div class="clear"></div>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<h4 class="f-copyright">
						Copyright © 2016 YAYASAN KONSERVASI ALAM NASIONAL
					</h4>
				</div>
				<div class="col-md-3">
					<ul class="social-net-footer">
						<li><a href="<?php echo ACCOUNT_FB;?>" target="_blank"><i class="fa fa-facebook-square"></i></a></li>
						<li><a href="<?php echo ACCOUNT_TW;?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
						<li><a href="<?php echo ACCOUNT_INS;?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
						<li><a href="<?php echo ACCOUNT_YTB;?>" target="_blank"><i class="fa fa-youtube"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>

<?php if($this->session->flashdata('msg')){ ?>
	<!-- Modal -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
		  <div class="modal-body text-center">
			<button type="button" class="close pull-right" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<?php echo translation($this->session->flashdata('msg'));?>
		  </div>
		</div>
	  </div>
	</div>
<?php } ?>
	
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo asset('web');?>/js/jquery-1.9.1.min.js"></script>
<script src="<?php echo asset('web');?>/js/owl.carousel.js"></script>
<script src="<?php echo asset('web');?>/js/wow.min.js"></script>
<script src="<?php echo asset('web');?>/js/jquery.fitvids.js"></script>
<script src="<?php echo asset('web');?>/js/lightbox.js"></script>
<script src="<?php echo asset('web');?>/js/ekko-lightbox.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo asset('web');?>/js/main.js"></script>
<script src="<?php echo asset('web');?>/js/bootstrap.min.js"></script>

<script>
	$(document).ready(function() {
		<?php if($this->session->flashdata('msg')){ ?>
		$('#myModal').modal('show'); 
		<?php } ?>
		
		window.fbAsyncInit = function() {
			FB.init({
				appId   : '<?php echo FBAPPID;?>',
				status	: true,
				cookie	: true,
				xfbml	: true,
				version	: 'v2.6'
			});
		};

		(function(d, s, id){
			var js, fjs = d.getElementsByTagName(s)[0];
			if (d.getElementById(id)) {return;}
			js = d.createElement(s); js.id = id;
			js.src = "//connect.facebook.net/en_US/sdk.js";
			fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));
	});
	
	function fbLogin() {
		FB.login(function(response){
			if (response.authResponse) {
				FB.api('/me?fields=id,name,email,picture,gender', function(response) {
					var sosid = response.id;
					var fullname = response.name;
					var email = response.email;
					var avatar = 'http://graph.facebook.com/'+ sosid +'/picture?type=normal';
					var gender = response.gender;

					if(sosid == 'undefined' || sosid == '' || sosid == null){ return false; }
					if(fullname == 'undefined' || fullname == '' || fullname == null){ return false; }
					if(email == 'undefined' || email == '' || email == null){ return false; }
					
					$.ajax({
						type: "POST",
						dataType: 'json',
						data: 'sosid='+ sosid + '&fullname='+ fullname + '&email='+ email + '&avatar='+ avatar + '&gender='+ gender + '&provider=facebook&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash();?>',
						url: '<?php echo base_url("auth/facebook"); ?>',
					}).done(function( data ) {
						window.location.href = '<?php echo base_url(); ?>';
					}).fail(function(error) {
					});
				});
			}
		}, {
			scope: 'public_profile,email,user_friends',
			return_scopes: true
		});
	}
	
	var winTop = (screen.height / 2) - 200;
	var winLeft = (screen.width / 2) - 325;
	
	function fbShare(identifier, e) {
		var title = $(identifier).data('title');
		var describe = $(identifier).data('describe');
		var cover = $(identifier).data('cover');
		var slug = $(identifier).data('slug');

		FB.ui( {
			method: 'feed',
			name: title,
			link: slug,
			picture: cover,
			caption: '<?php echo $_SERVER['HTTP_HOST'];?>',
			description: describe,
			redirect_uri: slug
		}, function( response ) {
		});
	}
	
	function twShare(identifier, e) {
		var title = $(identifier).data('title');
		var describe = $(identifier).data('describe');
		var cover = $(identifier).data('cover');
		var slug = $(identifier).data('slug');
		
		window.open('https://twitter.com/intent/tweet?url='+ slug +'&text='+ title +'&hashtags=&via=ykan','Twitter Share','top=' + winTop + ',left=' + winLeft + ',height=400,width=650');
	}
</script>
	
</body>
</html>