<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

		<footer class="main-footer">
			<div class="pull-right hidden-xs">Version 2.0</div>
			Development &copy; 2016. All rights reserved.
		</footer>
	</div><!-- ./wrapper -->