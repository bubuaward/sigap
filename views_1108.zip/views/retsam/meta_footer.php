<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

	<script>
	$(document).ready(function() {	
		<?php if($this->session->flashdata('msg')){ ?>
			$('body').append('<div class="notifpopx" id="notifpop-blank" style="display:block; display: block;position: fixed;right: 15px;z-index: 99999;top: 65px;">\
				<div class="notifpop-blockx" style="width: 320px; background-color: #222d32; color: #fff; text-align: center;padding: 18px 19px 10px 19px;">\
					<a href="javascript:;" class="notifpop-closed" style="float: right;margin:-15px 0px;color: rgb(255, 0, 0);font-size: 21px;"><i class="fa fa-times"></i></a>\
					<p style="border-bottom:1px solid #ccc;">Information System</p>\
					<p><?php echo $this->session->flashdata('msg');?></p>\
				</div>\
			</div>');
		<?php } ?>
		
		$('.notifpop-closed').click(function()
		{
			$('.notifpopx').fadeOut(300);
		});
		
		$('.date').datepicker({
			todayBtn: "linked",
			autoclose: true,
			format: 'yyyy-mm-dd',
			todayHighlight: true
		});
		
		$('.datetime').datetimepicker({	
			weekStart: 1,
			todayBtn:  1,
			autoclose: 1,
			todayHighlight: 1,
			startView: 2,
			forceParse: 0,
			showMeridian: 0
		});
		
		$('.inp').on('change keyup keydown', 'input, textarea, select', function () {
			$(this).addClass('changed-input');
		});

		$(".nextinp").click(function() {
			$('.inp input, .inp textarea, .inp select').removeClass('changed-input');
			$(this).submit();
		});

		$(window).on('beforeunload', function () {
			if ($('.changed-input').length) {
				return 'You haven\'t saved your changes.';
			}
		});
	});
	
	function checkedbutton(link){
		var answer = confirm('Hai <?php echo ($this->session->userdata('isloginaccount')? $this->session->userdata['isloginaccount']['fullname']:'Admin');?>, Are you sure want to perform this action?');
		if (answer){
			window.location = link;
		}
		return false;  
	}
	</script>
</body>
</html>